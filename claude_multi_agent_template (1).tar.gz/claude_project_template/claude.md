# Project Context: Multi-Agent Development System

This file provides the root context for a team of specialized AI agents working collaboratively on this project. The system implements a research-backed, production-ready workflow optimized for parallel execution, context window management, and code quality.

## Core Objective

[**Instructions for User:** Briefly describe the overall goal of the project in 2-3 sentences. Example:]

Build a task management application that allows teams to collaborate on projects, track progress, and manage deadlines. The system should support real-time updates, role-based access control, and integration with popular calendar services.

## Coding Standards

**All code must follow Google's official style guides.** This is a non-negotiable requirement for all agents.

- Consult `docs/code_conventions.md` for comprehensive Google style standards
- Use language-specific linters and formatters before submitting code
- Follow Google's code review and documentation guidelines

## Agent Team Structure & Interaction Patterns

This project uses **11 specialized agents** organized into a three-phase workflow. Each agent has a specific role and interacts with others through well-defined patterns.

### Phase 1: Planning & Architecture (Parallel Execution)

These agents work **concurrently** during the planning phase, each with their own dedicated 200k context window:

#### **Architect** (`.claude/agents/architect.md`)
- **Role:** System design, technology stack selection, architectural decision records (ADRs)
- **Invoked:** At project start and when major architectural decisions are needed
- **Produces:** `docs/architecture.md` with system design and ADRs
- **Interacts with:** Product Manager (provides technical constraints), Developers (provides architectural guidance)
- **Example:** `@architect Review plan.md and create the initial system architecture`

#### **Product Manager** (`.claude/agents/product_manager.md`)
- **Role:** Translates business requirements into detailed technical specifications
- **Invoked:** For each new feature or epic in `plan.md`
- **Produces:** `tasks/[feature-name].md` with user stories, acceptance criteria, technical requirements
- **Interacts with:** UX Designer (parallel planning), Architect (validates technical feasibility), Developers (provides requirements)
- **Example:** `@product_manager Create task.md for user authentication feature`

#### **UX Designer** (`.claude/agents/ux_designer.md`)
- **Role:** User experience design, wireframes, design systems, accessibility
- **Invoked:** In parallel with Product Manager during feature planning
- **Produces:** UI/UX specifications in `tasks/[feature-name].md`, design assets
- **Interacts with:** Product Manager (parallel planning), UI Developer (provides design specifications)
- **Example:** `@ux_designer Create wireframes and design specs for dashboard UI`

**Interaction Pattern:**
```
User Request → @product_manager @ux_designer (parallel invocation)
                    ↓                    ↓
            Requirements          Design Specs
                    └────────┬────────┘
                          task.md
```

### Phase 2: Development (Sequential Handoff)

These agents receive `task.md` from Phase 1 and implement the feature:

#### **UI Developer** (`.claude/agents/ui_developer.md`)
- **Role:** Frontend implementation, responsive design, component development
- **Invoked:** When `task.md` includes UI/UX specifications
- **Produces:** Frontend code, component tests
- **Interacts with:** UX Designer (receives design specs), Backend Developer (API integration), Code Reviewers (submits for review)
- **Follows:** Google HTML/CSS/JavaScript/TypeScript style guides
- **Example:** `@ui_developer Implement login UI from tasks/auth.md`

#### **Backend Developer** (`.claude/agents/backend_developer.md`)
- **Role:** API implementation, business logic, database design, server-side code
- **Invoked:** When `task.md` includes backend requirements
- **Produces:** Backend code, API endpoints, database migrations, unit/integration tests
- **Interacts with:** Architect (follows architecture), UI Developer (provides APIs), Code Reviewers (submits for review)
- **Follows:** Google Python/Java/Go/C++ style guides (depending on stack)
- **Example:** `@backend_developer Implement authentication API from tasks/auth.md`

**Interaction Pattern:**
```
task.md → @ui_developer (if UI needed)
       → @backend_developer (if backend needed)
       → Both (if full-stack feature)
```

### Phase 3: Quality Assurance (Sequential Review + Testing)

#### Multi-Level Code Review (Sequential with Feedback Loops)

**Code Reviewer I** (`.claude/agents/code_reviewer_I.md`)
- **Role:** Peer review - style, conventions, readability, basic logic
- **Invoked:** First review gate after developer completes implementation
- **Produces:** Structured review feedback (approve/reject + issues)
- **Interacts with:** Developer (provides feedback), Code Reviewer II (passes if approved)
- **Validates:** Google style guide adherence, code readability, basic correctness
- **Example:** `@code_reviewer_I Review authentication API implementation`

**Code Reviewer II** (`.claude/agents/code_reviewer_II.md`)
- **Role:** Senior review - architecture alignment, design patterns, performance, scalability
- **Invoked:** Second review gate (only if Code Reviewer I approves)
- **Produces:** Structured review feedback on architectural and design aspects
- **Interacts with:** Code Reviewer I (receives after first approval), Developer (provides feedback), CyberCodeReview (passes if approved)
- **Validates:** Architectural consistency, SOLID principles, performance considerations
- **Example:** `@code_reviewer_II Perform senior review of authentication API`

**CyberCodeReview** (`.claude/agents/cyber_code_reviewer.md`)
- **Role:** Security-focused review - vulnerabilities, OWASP Top 10, secure coding practices
- **Invoked:** Third review gate (only if Code Reviewer II approves)
- **Produces:** Security assessment with vulnerability reports and mitigation recommendations
- **Interacts with:** Code Reviewer II (receives after second approval), Developer (provides security feedback)
- **Validates:** Input validation, authentication/authorization, encryption, injection prevention
- **Example:** `@cyber_code_reviewer Perform security review of authentication API`

**Review Interaction Pattern:**
```
Developer Code → @code_reviewer_I → Approve/Reject
                        ↓ (if approved)
                 @code_reviewer_II → Approve/Reject
                        ↓ (if approved)
                 @cyber_code_reviewer → Approve/Reject
                        ↓ (if rejected at any stage)
                 ← Feedback Loop to Developer
```

#### Multi-Level Testing (Bottom-Up Sequential)

**Unit Test Agent** (`.claude/agents/unit_test_agent.md`)
- **Role:** Component-level testing, first validation gate
- **Invoked:** After all code reviews pass
- **Produces:** Unit test results, coverage reports
- **Interacts with:** Developer (receives code), Integration Test Agent (passes if tests pass)
- **Validates:** Individual functions/methods work correctly in isolation
- **Example:** `@unit_test_agent Run unit tests for authentication module`

**Integration Test Agent** (`.claude/agents/integration_test_agent.md`)
- **Role:** Component interaction testing, second validation gate
- **Invoked:** After unit tests pass
- **Produces:** Integration test results, API contract validation
- **Interacts with:** Unit Test Agent (receives after first gate), System Test Agent (passes if tests pass)
- **Validates:** Components work together correctly, API contracts respected
- **Example:** `@integration_test_agent Test authentication flow with database`

**System Test Agent** (`.claude/agents/system_test_agent.md`)
- **Role:** End-to-end testing, final validation gate
- **Invoked:** After integration tests pass
- **Produces:** System test results, performance metrics, user journey validation
- **Interacts with:** Integration Test Agent (receives after second gate), Documentation Specialist (passes if tests pass)
- **Validates:** Complete user journeys work in production-like environment
- **Example:** `@system_test_agent Test complete user registration and login flow`

**Testing Interaction Pattern (Bottom-Up):**
```
Code (after reviews) → @unit_test_agent → Pass/Fail
                            ↓ (if pass)
                       @integration_test_agent → Pass/Fail
                            ↓ (if pass)
                       @system_test_agent → Pass/Fail
                            ↓ (if pass)
                       Production Ready
```

### Support: Documentation

**Documentation Specialist** (`.claude/agents/documentation_specialist.md`)
- **Role:** Technical documentation, API references, user guides, tutorials
- **Invoked:** After feature passes all tests, or when documentation updates needed
- **Produces:** Documentation in `docs/` directory, API references, README updates
- **Interacts with:** All agents (documents their work), follows Google documentation style guide
- **Example:** `@documentation_specialist Document the authentication API`

## Development Workflow

The standard workflow follows a **three-phase process** with clear handoffs between phases:

### Workflow Execution Model

```
┌─────────────────────────────────────────────────────────────┐
│ Phase 1: Planning (PARALLEL)                                │
├─────────────────────────────────────────────────────────────┤
│ @product_manager + @ux_designer                             │
│ (Invoked simultaneously, each with 200k context)            │
│                                                             │
│ Output: tasks/[feature-name].md                             │
└─────────────────────┬───────────────────────────────────────┘
                      ↓ (handoff artifact)
┌─────────────────────────────────────────────────────────────┐
│ Phase 2: Implementation (SEQUENTIAL HANDOFF)                │
├─────────────────────────────────────────────────────────────┤
│ @ui_developer OR @backend_developer                         │
│ (Receives task.md, implements with 200k context)            │
│                                                             │
│ Output: Code + Tests                                        │
└─────────────────────┬───────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────────────┐
│ Phase 3a: Review (SEQUENTIAL with FEEDBACK LOOPS)           │
├─────────────────────────────────────────────────────────────┤
│ @code_reviewer_I → @code_reviewer_II → @cyber_code_reviewer │
│ (Each with 200k context, sequential gates)                  │
│                                                             │
│ If rejected: ← Loop feedback to developer                   │
│ If approved: → Continue to testing                          │
└─────────────────────┬───────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────────────┐
│ Phase 3b: Testing (BOTTOM-UP SEQUENTIAL)                    │
├─────────────────────────────────────────────────────────────┤
│ @unit_test_agent → @integration_test_agent → @system_test_agent │
│ (Each gate must pass before next, 200k context each)        │
│                                                             │
│ Output: Validated, Production-Ready Feature                 │
└─────────────────────┬───────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────────────┐
│ Documentation (PARALLEL, can run anytime after tests)       │
├─────────────────────────────────────────────────────────────┤
│ @documentation_specialist                                    │
│                                                             │
│ Output: Technical documentation                             │
└─────────────────────────────────────────────────────────────┘
```

## Agent Invocation Examples

### Single Feature Development (Full Cycle)

```bash
# 1. Plan (parallel)
@product_manager @ux_designer Create task.md for user profile page

# 2. Implement
@ui_developer Implement user profile UI from tasks/user-profile.md

# 3. Review (sequential)
@code_reviewer_I Review user profile UI code
@code_reviewer_II Review user profile UI code
@cyber_code_reviewer Review user profile UI code

# 4. Test (bottom-up sequential)
@unit_test_agent Test user profile components
@integration_test_agent Test user profile with backend
@system_test_agent Test complete user profile flow

# 5. Document
@documentation_specialist Document user profile feature
```

### Parallel Feature Development (Multiple Terminals)

**Terminal 1 (Feature A):**
```bash
@backend_developer Implement payment processing API from tasks/payment.md
```

**Terminal 2 (Feature B):**
```bash
@ui_developer Implement notification center from tasks/notifications.md
```

**Terminal 3 (Feature C):**
```bash
@backend_developer Implement analytics service from tasks/analytics.md
```

Each agent operates in its own 200k context window, preventing interference.

## Context Window Optimization

The template is designed to keep initial context usage **under 20%** of the 200k token limit:

- **This file (`claude.md`):** ~5k tokens (2.5%)
- **`plan.md`:** ~10k tokens (5%)
- **Agent definitions:** Loaded on-demand (~3k each)
- **Documentation:** Loaded on-demand (~15k each)
- **Remaining:** ~165k tokens (82.5%) for actual work

### Best Practices for Agents

1. **Progressive Disclosure:** Read `docs/` files only when the task requires specific context
2. **Just-in-Time Loading:** Use `grep` and `find` to locate information before reading entire files
3. **One Mission:** Focus on a single, well-defined task per session
4. **Context Management:** If context fills up, use `/export` and `/clear` to reset

## Critical Instructions for All Agents

1. **Follow Google Style Guides:** All code must adhere to the appropriate Google style guide for the language. Consult `docs/code_conventions.md` for details.

2. **Read Task Files:** Before implementing, thoroughly read the relevant `tasks/[feature-name].md` file to understand requirements and acceptance criteria.

3. **Validate Architecture:** Ensure your implementation aligns with the system architecture defined in `docs/architecture.md`.

4. **Write Tests:** All code must include comprehensive tests following Google's testing conventions.

5. **Structured Output:** Review agents must produce structured, parsable feedback to enable automated orchestration.

6. **Ask for Clarification:** If requirements are unclear or ambiguous, ask the orchestrator or user before proceeding.

7. **Document Decisions:** When making significant technical decisions, document them in ADRs or code comments explaining *why*, not just *what*.

## Additional Documentation

Detailed information is available in the `/docs` directory. **Load these files on-demand** when a task requires specific context:

- `docs/architecture.md` - System architecture, component diagrams, technology stack, ADRs
- `docs/testing_strategy.md` - Testing frameworks, coverage requirements, test naming conventions
- `docs/code_conventions.md` - **Google style guides, code review standards, commit message format**
- `docs/deployment.md` - Build instructions, deployment process, environment variables

## Project Management

- **Requirements & Features:** See `plan.md` for high-level project vision and feature list
- **Task Tracking:** Individual features are tracked in `tasks/[feature-name].md` files
- **Task Template:** Use `tasks/TASK_TEMPLATE.md` as a starting point for new features

## Resources

- **Claude Code Documentation:** https://code.claude.com/docs
- **Google Style Guides:** https://google.github.io/styleguide/
- **Google Engineering Practices:** https://google.github.io/eng-practices/
- **Usage Guide:** See `USAGE_GUIDE.md` for detailed workflow instructions
- **Quick Start:** See `QUICKSTART.md` for getting started in 5 minutes
