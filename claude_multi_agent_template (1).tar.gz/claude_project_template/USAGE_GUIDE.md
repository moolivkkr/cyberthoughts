# Claude Multi-Agent Project Template - Usage Guide

This guide explains how to use the Claude Multi-Agent Project Template to build software projects with a team of specialized AI agents.

## Overview

The template is designed around three core principles derived from extensive research into multi-agent systems and Claude Code best practices:

1. **Parallel Execution:** Independent tasks are executed concurrently by specialized agents, each with their own dedicated context window.
2. **Sequential Handoffs:** Complex workflows are automated through a series of handoffs, where the output of one agent becomes the input for the next.
3. **Context Isolation:** Each agent operates in its own context window, preserving the quality of specialized knowledge and preventing context degradation.

## Project Structure

```
claude_project_template/
├── claude.md                    # Root context file (auto-loaded by Claude Code)
├── plan.md                      # Project requirements and task tracking
├── .claude/
│   └── agents/                  # Sub-agent definitions
│       ├── architect.md
│       ├── product_manager.md
│       ├── ux_designer.md
│       ├── ui_developer.md
│       ├── backend_developer.md
│       ├── code_reviewer_I.md
│       ├── code_reviewer_II.md
│       ├── cyber_code_reviewer.md
│       ├── unit_test_agent.md
│       ├── integration_test_agent.md
│       ├── system_test_agent.md
│       └── documentation_specialist.md
└── docs/                        # Detailed documentation (progressive disclosure)
    ├── architecture.md
    ├── testing_strategy.md
    ├── code_conventions.md
    └── deployment.md
```

## Getting Started

### 1. Initialize Your Project

1. Copy this template directory to your project location
2. Open `claude.md` and fill in the **Core Objective** section with your project's goal
3. Open `plan.md` and define your high-level features and requirements

### 2. Define Your Architecture

Use the Architect agent to establish the technical foundation:

```bash
@architect Please review the requirements in plan.md and create the initial system architecture in docs/architecture.md
```

The architect will:
- Select the appropriate technology stack
- Design the system architecture
- Create Architectural Decision Records (ADRs)

### 3. Plan Your First Feature

Use the Product Manager and UX Designer agents in parallel to plan a feature:

```bash
@product_manager @ux_designer Please create a detailed task.md for [feature name] based on the requirements in plan.md
```

This will produce a `task.md` file containing:
- User story and acceptance criteria
- Technical requirements
- UI/UX specifications

### 4. Implement the Feature

Hand off the `task.md` to the appropriate developer agent:

**For Frontend Features:**
```bash
@ui_developer Please implement the feature described in task.md
```

**For Backend Features:**
```bash
@backend_developer Please implement the feature described in task.md
```

Each developer agent will:
- Implement the code according to the specifications
- Write unit tests
- Follow the code conventions in `docs/code_conventions.md`

### 5. Review the Code

Execute the three-tier review process sequentially:

```bash
@code_reviewer_I Please review the code changes for [feature name]
```

If approved:
```bash
@code_reviewer_II Please perform a senior review of the code changes for [feature name]
```

If approved:
```bash
@cyber_code_reviewer Please perform a security review of the code changes for [feature name]
```

The orchestrator should loop feedback back to the developer agent until all reviews pass.

### 6. Test the Feature

Execute the testing pyramid from bottom to top:

```bash
@unit_test_agent Please run unit tests for [feature name]
```

If passed:
```bash
@integration_test_agent Please run integration tests for [feature name]
```

If passed:
```bash
@system_test_agent Please run system tests for [feature name]
```

## Advanced Workflows

### Parallel Feature Development

To work on multiple independent features simultaneously, open multiple Claude Code terminals:

**Terminal 1:**
```bash
@ui_developer Implement feature A from tasks/feature-a.md
```

**Terminal 2:**
```bash
@backend_developer Implement feature B from tasks/feature-b.md
```

Each agent operates in its own context window, preventing interference.

### Automated Documentation

After implementing a feature, generate documentation:

```bash
@documentation_specialist Please document the new [feature name] feature
```

## Context Window Optimization

The template is designed to keep initial context usage under 20% of the 200k token limit. Key strategies:

1. **Progressive Disclosure:** Detailed documentation is in `/docs` and loaded on-demand
2. **Concise Root Context:** `claude.md` is kept under 60 lines
3. **Just-in-Time Loading:** Agents use `grep` and `find` to locate information before reading files
4. **One Mission Per Session:** Each agent focuses on a single task to avoid context contamination

## Best Practices

### For Orchestrators (Human or AI)

- **Delegate Appropriately:** Assign tasks to the agent best suited for the job
- **Provide Clear Context:** When invoking an agent, reference the relevant `task.md` or documentation
- **Manage Feedback Loops:** Automatically parse structured output from review agents and loop feedback to developers
- **Monitor Context Usage:** Use `/clear` and `/export` to manage context when approaching limits

### For Agent Invocation

- **Be Specific:** Clearly state the task and reference any relevant files
- **Invoke in Parallel:** When tasks are independent, invoke multiple agents simultaneously
- **Sequential for Dependencies:** When tasks have dependencies, invoke agents sequentially with handoffs

### For Task Management

- **Create Detailed `task.md` Files:** Each feature should have a comprehensive task file
- **Update `plan.md` Regularly:** Keep the project plan current with task statuses
- **Link Tasks:** Maintain links between `plan.md` and individual `task.md` files

## Troubleshooting

### Context Window Full

If an agent's context window fills up:
1. Use `/export` to save the conversation
2. Use `/clear` to start a fresh session
3. Paste the exported conversation back in
4. Continue with the task

### Agent Confusion

If an agent seems confused or off-track:
1. Check that you've provided the correct context (e.g., referenced the right `task.md`)
2. Ensure the agent's role definition in `.claude/agents/` is clear
3. Consider breaking the task into smaller, more focused subtasks

### Conflicting Changes

If multiple agents make conflicting changes:
1. Use git to manage conflicts
2. Assign a senior agent (Code Reviewer II or Architect) to resolve the conflict
3. Consider better task decomposition to avoid overlapping work

## Example Workflow

Here's a complete example of building a new feature:

```bash
# Step 1: Plan the feature (parallel)
@product_manager @ux_designer Create task.md for user authentication feature

# Step 2: Implement backend (sequential handoff)
@backend_developer Implement authentication API from tasks/auth.md

# Step 3: Review backend code (sequential)
@code_reviewer_I Review authentication API code
@code_reviewer_II Review authentication API code
@cyber_code_reviewer Review authentication API code

# Step 4: Test backend (sequential)
@unit_test_agent Test authentication API
@integration_test_agent Test authentication API

# Step 5: Implement frontend (parallel with backend if independent)
@ui_developer Implement login UI from tasks/auth.md

# Step 6: Review frontend code (sequential)
@code_reviewer_I Review login UI code
@code_reviewer_II Review login UI code

# Step 7: Test frontend (sequential)
@unit_test_agent Test login UI components
@integration_test_agent Test login flow

# Step 8: System test (final validation)
@system_test_agent Test complete authentication flow

# Step 9: Document (parallel)
@documentation_specialist Document authentication feature
```

## Customization

### Adding New Agents

To add a new specialized agent:

1. Create a new `.md` file in `.claude/agents/`
2. Define the agent's role, responsibilities, workflow, and critical instructions
3. Update `claude.md` to list the new agent

### Modifying Workflows

To customize the development workflow:

1. Edit the "Development Workflow" section in `claude.md`
2. Update agent definitions to reflect the new workflow
3. Adjust the orchestration logic in your commands or scripts

## Key Research Insights Applied

This template incorporates findings from multiple sources:

- **Context Engineering:** Progressive disclosure and just-in-time loading minimize context usage
- **Multi-Agent Coordination:** Orchestrator-worker pattern with parallel and sequential execution
- **Token Optimization:** Initial context kept under 20% of window; MCP tools loaded on-demand
- **Quality Through Isolation:** Each agent gets a fresh 200k context window for specialized work
- **Structured Artifacts:** Handoff documents like `task.md` enable automated orchestration

## Support

For questions or issues with the template, refer to:
- Claude Code documentation: https://code.claude.com/docs
- Anthropic best practices: https://www.anthropic.com/engineering/claude-code-best-practices
