# Code Conventions - Google Style Standards

This document defines the coding standards for the project. **All code must adhere to Google's official style guides** to ensure consistency, maintainability, and industry best practices.

## Official Google Style Guides

All agents and developers must follow the appropriate Google style guide for their language:

| Language | Style Guide URL |
|----------|----------------|
| **Python** | https://google.github.io/styleguide/pyguide.html |
| **JavaScript** | https://google.github.io/styleguide/jsguide.html |
| **TypeScript** | https://google.github.io/styleguide/tsguide.html |
| **Java** | https://google.github.io/styleguide/javaguide.html |
| **C++** | https://google.github.io/styleguide/cppguide.html |
| **Go** | https://google.github.io/styleguide/go/ |
| **HTML/CSS** | https://google.github.io/styleguide/htmlcssguide.html |
| **Shell** | https://google.github.io/styleguide/shellguide.html |
| **Objective-C** | https://google.github.io/styleguide/objcguide.html |
| **Swift** | https://google.github.io/styleguide/swift/ |

## Core Principles from Google

Google's style guides emphasize these universal principles across all languages:

### 1. Optimize for the Reader, Not the Writer

Code is read far more often than it is written. Write code that is easy to understand for someone encountering it for the first time. Clarity and explicitness are more important than brevity.

### 2. Be Consistent

Consistency within a codebase is critical. When in doubt, follow the existing patterns in the project. If there is no existing pattern, follow the Google style guide for your language.

### 3. Every Style Point Has a Purpose

Google's style guides are not arbitrary. Each rule exists to improve code health, reduce bugs, or make code easier to maintain. Understand the reasoning behind rules, not just the rules themselves.

### 4. Practicality Beats Purity

While consistency is important, sometimes breaking a rule makes code more readable or maintainable. Use judgment, but document why you're deviating from the standard.

## Language-Specific Quick Reference

### Python (PEP 8 + Google Extensions)

**Naming Conventions:**
- `module_name`, `package_name`, `ClassName`, `method_name`, `function_name`, `GLOBAL_CONSTANT_NAME`, `instance_var_name`, `function_parameter_name`, `local_var_name`

**Key Rules:**
- Use 4 spaces for indentation (never tabs)
- Maximum line length: 80 characters
- Use docstrings for all public modules, functions, classes, and methods
- Import order: standard library, third-party, local application
- Avoid mutable default arguments

**Example:**
```python
def fetch_bigtable_rows(big_table, keys, other_silly_variable=None):
    """Fetches rows from a Bigtable.

    Args:
        big_table: An open Bigtable Table instance.
        keys: A sequence of strings representing the key of each table row.
        other_silly_variable: Optional; description of parameter.

    Returns:
        A dict mapping keys to the corresponding table row data.
    """
    pass
```

### JavaScript/TypeScript

**Naming Conventions:**
- `fileName.js`, `ClassName`, `methodName`, `CONSTANT_NAME`, `variableName`

**Key Rules:**
- Use 2 spaces for indentation
- Use `const` or `let`, never `var`
- Always use semicolons
- Use single quotes for strings (unless escaping)
- Maximum line length: 80 characters
- Use JSDoc for all functions, classes, and methods

**Example:**
```javascript
/**
 * Computes the sum of two numbers.
 * @param {number} a The first number.
 * @param {number} b The second number.
 * @return {number} The sum of a and b.
 */
function sum(a, b) {
  return a + b;
}
```

### Java

**Naming Conventions:**
- `ClassName`, `methodName`, `CONSTANT_NAME`, `variableName`, `package.name`

**Key Rules:**
- Use 2 spaces for indentation
- Braces use K&R style (opening brace on same line)
- One top-level class per file
- Maximum line length: 100 characters
- Use Javadoc for all public classes and methods

**Example:**
```java
/**
 * Represents a user in the system.
 */
public class User {
  private final String name;
  
  /**
   * Creates a new user with the given name.
   * @param name the user's name
   */
  public User(String name) {
    this.name = name;
  }
}
```

### Go

**Naming Conventions:**
- `packageName`, `StructName`, `functionName`, `variableName`

**Key Rules:**
- Use tabs for indentation (gofmt standard)
- Exported names start with capital letter
- Use short variable names in small scopes
- Comment all exported functions, types, and constants
- Error handling: check all errors

**Example:**
```go
// User represents a user in the system.
type User struct {
    Name string
    Age  int
}

// NewUser creates a new user with the given name and age.
func NewUser(name string, age int) (*User, error) {
    if name == "" {
        return nil, errors.New("name cannot be empty")
    }
    return &User{Name: name, Age: age}, nil
}
```

## Code Review Standards (Google Engineering Practices)

All code reviews must follow Google's code review guidelines:

### The Standard of Code Review

**Primary Goal:** Make sure the overall code health of the codebase is improving over time.

**Key Principles:**
1. **Approve if the code improves overall code health**, even if it's not perfect
2. **No such thing as "perfect" code**, only better code
3. **Reviewers should favor approving** a CL once it definitely improves system health
4. **Balance:** Developers need to make progress, but code quality must not degrade

### What to Look For in Code Review

Code reviewers should examine:

1. **Design:** Is the code well-designed and appropriate for the system?
2. **Functionality:** Does the code behave as the author intended? Is it good for users?
3. **Complexity:** Could the code be simpler? Will another developer understand it?
4. **Tests:** Does the code have correct and well-designed automated tests?
5. **Naming:** Are names clear, descriptive, and appropriate?
6. **Comments:** Are comments clear, useful, and explain *why* not *what*?
7. **Style:** Does the code follow Google style guides?
8. **Documentation:** Did the author update relevant documentation?

### Review Speed

**Target:** One business day for initial response to a code review request.

**Why:** Fast reviews improve developer productivity and code quality. Slow reviews frustrate developers and encourage shortcuts.

## Documentation Standards

Follow Google's developer documentation style guide for all technical documentation:

**URL:** https://developers.google.com/style

**Key Principles:**
- Use sentence case for headings
- Write in second person ("you") when addressing the reader
- Use present tense
- Use active voice
- Keep sentences short and simple
- Use numbered lists for sequences, bulleted lists for non-sequential items

## Testing Standards

All code must include comprehensive tests following these principles:

### Test Coverage Requirements

- **Unit Tests:** Minimum 80% code coverage for all new code
- **Integration Tests:** All API endpoints and component interactions
- **System Tests:** All critical user journeys

### Test Naming

Follow Google's test naming convention:
```
testMethodName_stateUnderTest_expectedBehavior
```

**Example:**
```python
def test_fetch_user_valid_id_returns_user():
    """Test that fetching a user with valid ID returns the user."""
    pass

def test_fetch_user_invalid_id_raises_not_found():
    """Test that fetching a user with invalid ID raises NotFoundError."""
    pass
```

## Git Commit Message Standards

Follow the guidelines from "How to Write a Git Commit Message":

**Format:**
```
Summarize changes in 50 characters or less

More detailed explanatory text, if necessary. Wrap it to about 72
characters. The blank line separating the summary from the body is
critical.

Explain the problem that this commit is solving. Focus on why you
are making this change as opposed to how. Are there side effects?

- Bullet points are okay, too
- Use a hyphen or asterisk for the bullet

Fixes #123
```

**Seven Rules:**
1. Separate subject from body with a blank line
2. Limit the subject line to 50 characters
3. Capitalize the subject line
4. Do not end the subject line with a period
5. Use the imperative mood in the subject line
6. Wrap the body at 72 characters
7. Use the body to explain *what* and *why* vs. *how*

## Enforcement

### Automated Tools

Use language-specific linters and formatters to enforce style:

| Language | Linter/Formatter |
|----------|-----------------|
| Python | `pylint`, `black`, `isort` |
| JavaScript/TypeScript | `eslint`, `prettier` |
| Java | `checkstyle`, `google-java-format` |
| Go | `gofmt`, `golint`, `go vet` |
| C++ | `cpplint`, `clang-format` |

### Pre-Commit Hooks

Configure pre-commit hooks to run linters automatically:

```bash
# Example .pre-commit-config.yaml
repos:
  - repo: https://github.com/psf/black
    rev: 23.1.0
    hooks:
      - id: black
  - repo: https://github.com/PyCQA/pylint
    rev: v2.16.0
    hooks:
      - id: pylint
```

### Code Review Checklist

All code reviewers must verify:

- [ ] Code follows the appropriate Google style guide
- [ ] All public APIs have documentation
- [ ] Tests are included and follow naming conventions
- [ ] Commit messages follow the standard format
- [ ] No linter warnings or errors
- [ ] Code is readable and maintainable

## Resources

- **Google Style Guides:** https://google.github.io/styleguide/
- **Google Engineering Practices:** https://google.github.io/eng-practices/
- **Google Developer Documentation Style:** https://developers.google.com/style
- **How to Write a Git Commit Message:** https://chris.beams.io/posts/git-commit/

## Agent Responsibilities

All development agents (UI Developer, Backend Developer) must:
1. Consult the appropriate Google style guide before writing code
2. Run automated linters/formatters before submitting code for review
3. Include tests that follow Google's testing conventions
4. Write commit messages following the standard format

All review agents (Code Reviewer I, II, CyberCodeReview) must:
1. Verify adherence to Google style guides
2. Check for proper documentation and comments
3. Ensure tests follow naming and coverage standards
4. Validate commit message format and content
