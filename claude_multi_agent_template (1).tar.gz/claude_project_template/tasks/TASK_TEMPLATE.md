# Task: [Feature Name]

**Status:** [To Do / In Progress / In Review / Done]  
**Assigned To:** [Agent Name]  
**Created:** [Date]  
**Last Updated:** [Date]

## User Story

As a [user type], I want to [action] so that [benefit].

## Acceptance Criteria

- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Technical Requirements

### Architecture
- Component/service affected: [e.g., User Service, Payment API]
- Dependencies: [e.g., Authentication Service, Database]
- Technology stack: [e.g., Node.js, PostgreSQL, React]

### API Endpoints (if applicable)
- `POST /api/[endpoint]` - [Description]
  - Request: `{ field: type }`
  - Response: `{ field: type }`
  - Status codes: 200, 400, 401, 500

### Database Changes (if applicable)
- New tables: [Table name and schema]
- Modified tables: [Changes to existing tables]
- Migrations: [Migration strategy]

## UI/UX Specifications

### Wireframes
[Link to wireframes or description of layout]

### Design Assets
- Colors: [Hex codes]
- Typography: [Font families and sizes]
- Icons: [Icon names or links]

### User Flow
1. User navigates to [page]
2. User clicks [button/link]
3. System displays [result]

### Responsive Design
- Mobile: [Specific considerations]
- Tablet: [Specific considerations]
- Desktop: [Specific considerations]

## Implementation Notes

### Frontend
- Components to create: [List of components]
- State management: [Redux, Context API, etc.]
- Validation: [Client-side validation rules]

### Backend
- Business logic: [Key algorithms or processes]
- Validation: [Server-side validation rules]
- Error handling: [Expected errors and responses]

### Testing
- Unit tests: [Key test cases]
- Integration tests: [Integration points to test]
- System tests: [End-to-end scenarios]

## Security Considerations

- Authentication: [Required authentication level]
- Authorization: [Required permissions]
- Input validation: [Validation rules]
- Data encryption: [Encryption requirements]

## Performance Considerations

- Expected load: [e.g., 1000 requests/second]
- Response time target: [e.g., <200ms]
- Caching strategy: [If applicable]

## Dependencies

- Blocked by: [Other tasks that must be completed first]
- Blocks: [Other tasks that depend on this one]
- Related to: [Other related tasks]

## Questions and Clarifications

- [ ] Question 1
- [ ] Question 2

## Implementation Log

### [Date] - [Agent Name]
- [Action taken]
- [Decisions made]
- [Issues encountered]

## Review Checklist

### Code Reviewer I
- [ ] Code follows style guide
- [ ] Code is readable and maintainable
- [ ] No obvious bugs or logic errors

### Code Reviewer II
- [ ] Architecture aligns with system design
- [ ] Design patterns used appropriately
- [ ] Performance is acceptable

### CyberCodeReview
- [ ] No security vulnerabilities
- [ ] Input validation is comprehensive
- [ ] Authentication/authorization is correct

### Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] System tests pass
