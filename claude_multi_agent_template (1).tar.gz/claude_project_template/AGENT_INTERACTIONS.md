# Agent Interaction Patterns & Examples

This document provides concrete examples of how agents interact with each other throughout the development lifecycle, demonstrating the multi-agent orchestration in action.

## Overview

The 11-agent system uses three primary interaction patterns:

1. **Parallel Execution** - Multiple agents work simultaneously on independent tasks
2. **Sequential Handoff** - Output of one agent becomes input for the next
3. **Feedback Loop** - Iterative refinement through reviewer-developer cycles

## Complete Feature Development Example

### Scenario: Building a User Authentication System

This example demonstrates all agent interactions from planning through deployment.

---

### Phase 1: Planning (Parallel Execution)

**Orchestrator Action:**
```bash
@product_manager @ux_designer Please create a comprehensive task.md for 
a user authentication system including login, registration, password reset, 
and session management. Base requirements on plan.md section 2.3.
```

**What Happens:**

**Product Manager (200k context):**
- Reads `plan.md` section 2.3
- Analyzes user stories and business requirements
- Defines acceptance criteria
- Specifies API requirements
- Documents security requirements
- Creates technical requirements section

**UX Designer (200k context, working in parallel):**
- Reads `plan.md` section 2.3
- Reviews existing design system
- Creates wireframes for login, registration, password reset flows
- Defines user journey and error states
- Specifies accessibility requirements (WCAG compliance)
- Documents responsive design breakpoints

**Output:** `tasks/user-authentication.md`

**Content includes:**
- User stories with acceptance criteria
- Technical requirements (JWT tokens, bcrypt hashing, rate limiting)
- API endpoint specifications
- Database schema requirements
- UI/UX wireframes and user flows
- Security considerations (OWASP compliance)
- Performance requirements (<200ms response time)

**Interaction Pattern:**
```
Orchestrator
    ├─→ @product_manager (independent context)
    │       └─→ Analyzes business requirements
    │       └─→ Writes technical specs
    │
    └─→ @ux_designer (independent context)
            └─→ Creates wireframes
            └─→ Defines user flows
            
Both agents collaborate to produce unified task.md
```

---

### Phase 2: Architecture Review

**Orchestrator Action:**
```bash
@architect Please review tasks/user-authentication.md and ensure it aligns 
with our system architecture. Update docs/architecture.md with any new 
components or ADRs needed for authentication.
```

**What Happens:**

**Architect (200k context):**
- Reads `tasks/user-authentication.md`
- Reviews current `docs/architecture.md`
- Validates technology choices (e.g., JWT vs. session cookies)
- Creates ADR-005: Authentication Strategy
- Updates component diagram with AuthService
- Specifies database schema for users and sessions tables
- Documents integration points with existing services

**Output:** Updated `docs/architecture.md`

**Interaction Pattern:**
```
task.md → @architect → Updated architecture.md
                    → New ADR-005
```

---

### Phase 3: Backend Implementation

**Orchestrator Action:**
```bash
@backend_developer Please implement the authentication API from 
tasks/user-authentication.md. Follow the architecture in docs/architecture.md 
and Google's Python style guide in docs/code_conventions.md.
```

**What Happens:**

**Backend Developer (200k context):**
- Reads `tasks/user-authentication.md` (requirements)
- Reads `docs/architecture.md` (system design)
- Reads `docs/code_conventions.md` (Google Python style guide)
- Implements:
  - `POST /api/auth/register` - User registration
  - `POST /api/auth/login` - User login
  - `POST /api/auth/logout` - User logout
  - `POST /api/auth/reset-password` - Password reset
  - `AuthService` class with bcrypt password hashing
  - JWT token generation and validation
  - Database models for User and Session
  - Rate limiting middleware
- Writes unit tests for all functions
- Runs `pylint` and `black` formatter
- Creates commit with proper message format

**Output:** 
- `src/services/auth_service.py`
- `src/api/auth_routes.py`
- `src/models/user.py`
- `src/models/session.py`
- `tests/test_auth_service.py`
- `tests/test_auth_routes.py`

**Interaction Pattern:**
```
task.md + architecture.md + code_conventions.md
    ↓
@backend_developer (200k context)
    ↓
Backend code + tests
```

---

### Phase 4: Code Review (Sequential with Feedback Loops)

#### Review Gate 1: Peer Review

**Orchestrator Action:**
```bash
@code_reviewer_I Please review the authentication API implementation. 
Check for Google Python style guide compliance, code readability, and 
basic correctness.
```

**What Happens:**

**Code Reviewer I (200k context):**
- Reads all code files from backend developer
- Checks Google Python style guide compliance:
  - ✅ Naming conventions (snake_case for functions/variables)
  - ✅ Docstrings for all public functions
  - ✅ 4-space indentation
  - ❌ Line length exceeds 80 characters in auth_routes.py:45
  - ❌ Missing docstring for `_validate_password_strength()` helper
- Checks readability:
  - ✅ Clear variable names
  - ❌ Complex nested if-statements in `register()` function
- Checks tests:
  - ✅ Test naming follows convention
  - ✅ Good coverage of edge cases

**Output:** Structured review feedback
```json
{
  "status": "rejected",
  "issues": [
    {
      "severity": "major",
      "location": "src/api/auth_routes.py:45",
      "description": "Line exceeds 80 characters (Google Python style guide)",
      "recommendation": "Break into multiple lines using parentheses"
    },
    {
      "severity": "major",
      "location": "src/services/auth_service.py:78",
      "description": "Missing docstring for _validate_password_strength()",
      "recommendation": "Add docstring explaining password requirements"
    },
    {
      "severity": "minor",
      "location": "src/api/auth_routes.py:32-40",
      "description": "Complex nested if-statements reduce readability",
      "recommendation": "Extract validation logic into separate function"
    }
  ]
}
```

**Feedback Loop:**

**Orchestrator Action:**
```bash
@backend_developer Please address the following review feedback from 
Code Reviewer I:
[paste structured feedback]
```

**Backend Developer (same context, continued):**
- Fixes line length issue
- Adds missing docstring
- Refactors nested if-statements into `_validate_registration_input()` function
- Re-runs linters
- Updates commit

**Orchestrator Action:**
```bash
@code_reviewer_I Please re-review the updated authentication API code.
```

**Code Reviewer I:**
- Reviews updated code
- Verifies all issues addressed
- **Status: APPROVED**

**Interaction Pattern:**
```
Code → @code_reviewer_I → Rejected with feedback
           ↓
       Feedback → @backend_developer → Fixed code
           ↓
       Fixed code → @code_reviewer_I → APPROVED
```

#### Review Gate 2: Senior Review

**Orchestrator Action:**
```bash
@code_reviewer_II Please perform a senior architectural review of the 
authentication API. Check for architecture alignment, design patterns, 
performance, and scalability.
```

**What Happens:**

**Code Reviewer II (200k context):**
- Reads code files and `docs/architecture.md`
- Checks architectural alignment:
  - ✅ Follows ADR-005 authentication strategy
  - ✅ Proper separation of concerns (routes, services, models)
  - ✅ Uses dependency injection for database connections
- Checks design patterns:
  - ✅ Service layer pattern implemented correctly
  - ❌ Password hashing should use bcrypt work factor from config
  - ❌ JWT secret key hardcoded instead of environment variable
- Checks performance:
  - ✅ Database queries use indexes
  - ❌ Missing caching for frequently accessed user sessions
- Checks scalability:
  - ✅ Stateless JWT tokens enable horizontal scaling
  - ✅ Rate limiting prevents abuse

**Output:** Structured review feedback
```json
{
  "status": "rejected",
  "issues": [
    {
      "severity": "critical",
      "location": "src/services/auth_service.py:23",
      "description": "JWT secret key is hardcoded (security and config issue)",
      "recommendation": "Load from environment variable using os.getenv('JWT_SECRET')"
    },
    {
      "severity": "major",
      "location": "src/services/auth_service.py:45",
      "description": "Bcrypt work factor is hardcoded at 12",
      "recommendation": "Load from config to allow tuning without code changes"
    },
    {
      "severity": "minor",
      "location": "src/services/auth_service.py:67",
      "description": "Missing caching for session validation",
      "recommendation": "Consider Redis cache for active sessions to reduce DB load"
    }
  ]
}
```

**Feedback Loop:**

**Orchestrator Action:**
```bash
@backend_developer Please address the senior review feedback:
[paste structured feedback]
```

**Backend Developer:**
- Moves JWT secret to environment variable
- Moves bcrypt work factor to config file
- Adds Redis caching for session validation
- Updates `docs/deployment.md` with new environment variables
- Re-runs tests

**Orchestrator Action:**
```bash
@code_reviewer_II Please re-review the updated code.
```

**Code Reviewer II:**
- Verifies all architectural issues addressed
- **Status: APPROVED**

#### Review Gate 3: Security Review

**Orchestrator Action:**
```bash
@cyber_code_reviewer Please perform a comprehensive security review of 
the authentication API. Check for OWASP Top 10 vulnerabilities and 
secure coding practices.
```

**What Happens:**

**CyberCodeReview (200k context):**
- Reads code with security focus
- Checks OWASP Top 10:
  - ✅ A01: Broken Access Control - JWT validation on protected routes
  - ✅ A02: Cryptographic Failures - bcrypt for passwords, secure JWT
  - ✅ A03: Injection - Parameterized queries prevent SQL injection
  - ❌ A04: Insecure Design - No account lockout after failed attempts
  - ✅ A05: Security Misconfiguration - Proper error handling
  - ✅ A06: Vulnerable Components - Dependencies up to date
  - ❌ A07: Authentication Failures - Missing MFA support
  - ✅ A08: Software and Data Integrity - Signed JWT tokens
  - ❌ A09: Logging Failures - Insufficient security event logging
  - ✅ A10: SSRF - No external URL fetching
- Checks secure coding:
  - ✅ Input validation on all endpoints
  - ✅ Password strength requirements enforced
  - ❌ Timing attack vulnerability in password comparison

**Output:** Security assessment
```json
{
  "status": "rejected",
  "vulnerabilities": [
    {
      "severity": "high",
      "category": "A04: Insecure Design",
      "location": "src/api/auth_routes.py:login()",
      "description": "No account lockout mechanism after failed login attempts",
      "risk": "Enables brute force attacks on user passwords",
      "recommendation": "Implement account lockout after 5 failed attempts within 15 minutes"
    },
    {
      "severity": "medium",
      "category": "A09: Logging Failures",
      "location": "src/services/auth_service.py",
      "description": "Insufficient logging of security events",
      "risk": "Difficult to detect and respond to security incidents",
      "recommendation": "Log all authentication events (success/failure) with timestamps and IP addresses"
    },
    {
      "severity": "medium",
      "category": "Timing Attack",
      "location": "src/services/auth_service.py:87",
      "description": "Password comparison may be vulnerable to timing attacks",
      "risk": "Attacker could infer password length through timing analysis",
      "recommendation": "Use constant-time comparison function"
    }
  ]
}
```

**Feedback Loop:**

**Orchestrator Action:**
```bash
@backend_developer Please address the critical security vulnerabilities:
[paste security assessment]
```

**Backend Developer:**
- Implements account lockout mechanism with Redis
- Adds comprehensive security event logging
- Uses `secrets.compare_digest()` for constant-time password comparison
- Updates tests to cover new security features

**Orchestrator Action:**
```bash
@cyber_code_reviewer Please re-review the security fixes.
```

**CyberCodeReview:**
- Verifies all vulnerabilities addressed
- **Status: APPROVED**

**Interaction Pattern:**
```
Code (after Code Reviewer II) → @cyber_code_reviewer → Security assessment
                                        ↓ (if vulnerabilities found)
                                    Feedback → @backend_developer → Fixes
                                        ↓
                                    Fixed code → @cyber_code_reviewer → APPROVED
```

---

### Phase 5: Testing (Bottom-Up Sequential)

#### Test Gate 1: Unit Tests

**Orchestrator Action:**
```bash
@unit_test_agent Please run unit tests for the authentication module. 
Ensure all components work correctly in isolation.
```

**What Happens:**

**Unit Test Agent (200k context):**
- Runs existing unit tests written by backend developer
- Executes: `pytest tests/test_auth_service.py tests/test_auth_routes.py -v --cov`
- Checks coverage: 92% (exceeds 80% requirement)
- All 47 tests pass
- Validates:
  - Password hashing works correctly
  - JWT token generation and validation
  - Input validation logic
  - Error handling for edge cases

**Output:**
```
✅ PASS: 47/47 tests passed
✅ PASS: Code coverage 92% (target: 80%)
✅ PASS: All edge cases covered
Status: APPROVED - Proceed to integration tests
```

#### Test Gate 2: Integration Tests

**Orchestrator Action:**
```bash
@integration_test_agent Please run integration tests for the authentication 
system. Test interactions with database, Redis cache, and API contracts.
```

**What Happens:**

**Integration Test Agent (200k context):**
- Writes integration tests if not already present
- Sets up test database with seeded data
- Sets up test Redis instance
- Tests:
  - Registration flow (API → Service → Database)
  - Login flow with session creation
  - Password reset flow with email service (mocked)
  - Token refresh flow
  - Account lockout mechanism with Redis
  - Session caching with Redis
- Validates API contracts match specifications in `tasks/user-authentication.md`

**Output:**
```
✅ PASS: Registration flow end-to-end
✅ PASS: Login flow with session creation
✅ PASS: Password reset flow
✅ PASS: Token refresh mechanism
✅ PASS: Account lockout after 5 failed attempts
✅ PASS: Session caching reduces DB queries by 80%
✅ PASS: API contracts match specifications
Status: APPROVED - Proceed to system tests
```

#### Test Gate 3: System Tests

**Orchestrator Action:**
```bash
@system_test_agent Please run end-to-end system tests for complete user 
authentication journeys in a production-like environment.
```

**What Happens:**

**System Test Agent (200k context):**
- Deploys to staging environment
- Runs end-to-end tests simulating real user behavior:
  - New user registration → email verification → first login
  - Existing user login → access protected resource → logout
  - Forgot password → reset link → new password → login
  - Failed login attempts → account lockout → unlock after timeout
- Tests performance under load:
  - 1000 concurrent login requests
  - Response time: avg 145ms (target: <200ms)
- Tests security:
  - HTTPS enforcement
  - CORS configuration
  - Rate limiting effectiveness

**Output:**
```
✅ PASS: Complete registration and first login journey
✅ PASS: Login and access protected resources
✅ PASS: Password reset flow
✅ PASS: Account lockout and recovery
✅ PASS: Performance under load (145ms avg, target <200ms)
✅ PASS: Security configurations correct
✅ PASS: All acceptance criteria met
Status: APPROVED - Feature ready for production
```

**Interaction Pattern:**
```
Code (after all reviews) → @unit_test_agent → PASS
                                ↓
                           @integration_test_agent → PASS
                                ↓
                           @system_test_agent → PASS
                                ↓
                           Production Ready
```

---

### Phase 6: Documentation

**Orchestrator Action:**
```bash
@documentation_specialist Please create comprehensive documentation for 
the authentication system, including API reference, usage examples, and 
security considerations.
```

**What Happens:**

**Documentation Specialist (200k context):**
- Reads implemented code
- Reads `tasks/user-authentication.md` for requirements
- Creates documentation:
  - API reference with request/response examples
  - Authentication flow diagrams
  - Security best practices for API consumers
  - Environment variable configuration guide
  - Troubleshooting common issues
- Updates `README.md` with authentication section
- Follows Google documentation style guide

**Output:**
- `docs/api/authentication.md` - Complete API reference
- `docs/guides/authentication-setup.md` - Setup guide
- `docs/security/authentication-security.md` - Security considerations
- Updated `README.md`

---

## Parallel Development Example

### Scenario: Three Independent Features Simultaneously

**Terminal 1:**
```bash
@backend_developer Implement payment processing API from tasks/payment.md
```

**Terminal 2:**
```bash
@ui_developer Implement notification center UI from tasks/notifications.md
```

**Terminal 3:**
```bash
@backend_developer Implement analytics service from tasks/analytics.md
```

**What Happens:**

Each agent operates in its own 200k context window:
- **Terminal 1 Backend Developer:** Focuses solely on payment integration (Stripe API, webhooks, refunds)
- **Terminal 2 UI Developer:** Focuses solely on notification UI (real-time updates, toast messages, notification center)
- **Terminal 3 Backend Developer:** Focuses solely on analytics (event tracking, aggregation, reporting)

**No interference** between agents because:
- Each has dedicated context window
- Features are independent (no shared files)
- Each follows same Google style standards
- Each will go through same review and testing gates

**Interaction Pattern:**
```
Orchestrator
    ├─→ Terminal 1: @backend_developer (200k context)
    │       └─→ Payment API implementation
    │
    ├─→ Terminal 2: @ui_developer (200k context)
    │       └─→ Notification UI implementation
    │
    └─→ Terminal 3: @backend_developer (200k context)
            └─→ Analytics service implementation

All three proceed independently through review and testing
```

---

## Agent Communication Summary

### Direct Interactions

| From Agent | To Agent | Interaction Type | Artifact |
|------------|----------|------------------|----------|
| Product Manager | UX Designer | Parallel collaboration | task.md |
| Product Manager | Architect | Validation request | Architecture constraints |
| UX Designer | UI Developer | Handoff | Design specifications |
| Architect | Developers | Guidance | Architecture decisions |
| Backend Developer | Code Reviewer I | Submission | Code for review |
| Code Reviewer I | Backend Developer | Feedback loop | Review feedback |
| Code Reviewer I | Code Reviewer II | Handoff | Approved code |
| Code Reviewer II | Backend Developer | Feedback loop | Architectural feedback |
| Code Reviewer II | CyberCodeReview | Handoff | Approved code |
| CyberCodeReview | Backend Developer | Feedback loop | Security feedback |
| CyberCodeReview | Unit Test Agent | Handoff | Approved code |
| Unit Test Agent | Integration Test Agent | Handoff | Tested code |
| Integration Test Agent | System Test Agent | Handoff | Integration-tested code |
| System Test Agent | Documentation Specialist | Handoff | Production-ready feature |
| All Agents | Documentation Specialist | Information source | Implementation details |

### Context Isolation Benefits

Each agent maintains its own 200k context window, which means:
- **Product Manager** can focus entirely on business requirements without holding technical implementation details
- **UX Designer** can focus on user experience without database schemas cluttering context
- **Backend Developer** receives concise task.md and can dedicate full context to implementation
- **Code Reviewers** can focus on their specific review criteria without implementation noise
- **Test Agents** can focus on validation without planning discussions

This isolation is the **key to quality** - each agent preserves specialized knowledge throughout its work.

---

## Key Takeaways

1. **Parallel execution** speeds up independent work (planning, multi-feature development)
2. **Sequential handoffs** ensure quality through specialized review gates
3. **Feedback loops** enable iterative refinement until standards are met
4. **Context isolation** preserves quality by giving each agent dedicated 200k window
5. **Structured artifacts** (task.md, review feedback) enable automated orchestration
6. **Google standards** enforced at every stage through agent instructions and reviews
