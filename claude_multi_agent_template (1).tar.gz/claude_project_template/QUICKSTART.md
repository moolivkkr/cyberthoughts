# Quick Start Guide

Get started with the Claude Multi-Agent Project Template in 5 minutes.

## Step 1: Copy the Template

```bash
# Copy the entire template directory to your project location
cp -r claude_project_template/ /path/to/your/project/
cd /path/to/your/project/
```

## Step 2: Define Your Project

### Edit `claude.md`

Open `claude.md` and replace the placeholder in the **Core Objective** section:

```markdown
## Core Objective

[Describe your project in 2-3 sentences. Example:]
Build a task management application that allows teams to collaborate on projects,
track progress, and manage deadlines. The system should support real-time updates,
role-based access control, and integration with popular calendar services.
```

### Edit `plan.md`

Open `plan.md` and fill in:

1. **Project Vision & Goals:** What problem are you solving?
2. **High-Level Features:** List 3-5 major features (epics)
3. **Non-Functional Requirements:** Performance, security, scalability needs

## Step 3: Set Up Architecture

Open Claude Code and invoke the architect:

```bash
@architect Please review the requirements in plan.md and create the initial 
system architecture in docs/architecture.md. Include technology stack 
recommendations and an architectural decision record for the key choices.
```

The architect will:
- Propose a technology stack
- Design the system architecture
- Create ADRs for major decisions

## Step 4: Plan Your First Feature

Choose one feature from your `plan.md` and create a detailed task:

```bash
@product_manager @ux_designer Please create a detailed task.md file in the 
tasks/ directory for [feature name]. Base it on the requirements in plan.md 
and the architecture in docs/architecture.md.
```

This will produce a comprehensive `tasks/[feature-name].md` file with:
- User story and acceptance criteria
- Technical requirements
- UI/UX specifications

## Step 5: Implement the Feature

### For Backend Features

```bash
@backend_developer Please implement the feature described in 
tasks/[feature-name].md. Follow the architecture in docs/architecture.md 
and the coding conventions in docs/code_conventions.md.
```

### For Frontend Features

```bash
@ui_developer Please implement the feature described in 
tasks/[feature-name].md. Follow the design specifications and coding 
conventions in docs/code_conventions.md.
```

## Step 6: Review the Code

Run the three-tier review process:

```bash
# Peer review
@code_reviewer_I Please review the code changes for [feature-name]

# Senior review (only if peer review passes)
@code_reviewer_II Please perform a senior review of the code changes for [feature-name]

# Security review (only if senior review passes)
@cyber_code_reviewer Please perform a security review of the code changes for [feature-name]
```

If any review fails, the feedback will be provided. Loop it back to the developer:

```bash
@backend_developer Please address the following review feedback: [paste feedback]
```

## Step 7: Test the Feature

Run the testing pyramid from bottom to top:

```bash
# Unit tests
@unit_test_agent Please run unit tests for [feature-name]

# Integration tests (only if unit tests pass)
@integration_test_agent Please run integration tests for [feature-name]

# System tests (only if integration tests pass)
@system_test_agent Please run system tests for [feature-name]
```

## Step 8: Document the Feature

```bash
@documentation_specialist Please create documentation for the [feature-name] 
feature, including API reference, usage examples, and any configuration 
requirements.
```

## Next Steps

Now that you've completed your first feature, you can:

1. **Plan More Features:** Repeat steps 4-8 for additional features
2. **Parallelize Work:** Open multiple Claude Code terminals to work on independent features simultaneously
3. **Customize Agents:** Edit agent definitions in `.claude/agents/` to match your workflow
4. **Refine Documentation:** Update `docs/` files as your project evolves

## Pro Tips

### Parallel Development

Work on multiple features at once by opening multiple terminals:

**Terminal 1:**
```bash
@backend_developer Implement authentication API from tasks/auth.md
```

**Terminal 2:**
```bash
@ui_developer Implement dashboard UI from tasks/dashboard.md
```

### Context Management

If an agent's context gets full:
1. Use `/export` to save the conversation
2. Use `/clear` to start fresh
3. Paste the exported content back in
4. Continue with the task

### Structured Feedback

When looping feedback from reviewers to developers, be specific:

```bash
@backend_developer Please address these issues from Code Reviewer II:
1. The UserService.authenticate() method should use bcrypt for password hashing
2. Add error handling for database connection failures
3. Extract the validation logic into a separate validator class
```

## Common Commands

```bash
# Architecture
@architect Review and update the system architecture

# Planning
@product_manager Create task.md for [feature]
@ux_designer Create wireframes for [feature]

# Development
@backend_developer Implement [feature]
@ui_developer Implement [feature]

# Review
@code_reviewer_I Review [feature]
@code_reviewer_II Review [feature]
@cyber_code_reviewer Review [feature]

# Testing
@unit_test_agent Test [feature]
@integration_test_agent Test [feature]
@system_test_agent Test [feature]

# Documentation
@documentation_specialist Document [feature]
```

## Troubleshooting

### "Agent doesn't understand the task"

**Solution:** Provide more context by referencing specific files:

```bash
@backend_developer Please implement the user authentication feature 
described in tasks/auth.md. Refer to docs/architecture.md for the 
database schema and docs/code_conventions.md for coding standards.
```

### "Multiple agents making conflicting changes"

**Solution:** Better task decomposition. Ensure each task is independent:

- **Good:** "Implement user authentication API" and "Implement product catalog API"
- **Bad:** "Implement user service" and "Implement authentication" (both touch same files)

### "Review process taking too long"

**Solution:** This is intentional - quality over speed. However, you can:
- Run reviews on different features in parallel across multiple terminals
- Adjust review agent definitions to focus on most critical issues

## Need Help?

- **Full Documentation:** See [USAGE_GUIDE.md](USAGE_GUIDE.md)
- **Research Background:** See [RESEARCH_SUMMARY.md](/home/ubuntu/RESEARCH_SUMMARY.md)
- **Claude Code Docs:** https://code.claude.com/docs
- **Best Practices:** https://www.anthropic.com/engineering/claude-code-best-practices

---

**You're ready to build!** Start with one feature and iterate. The template will guide you through the process.
